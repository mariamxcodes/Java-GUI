
package gui03;

import com.formdev.flatlaf.FlatLightLaf;
import java.awt.EventQueue;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.UIManager;
import javax.swing.WindowConstants;

public class Gui03   extends JFrame {

    private int count = 0;
    private JButton bt = new JButton("Click");
    private JLabel lb = new JLabel(String.format("Number of Clicks: %3d", count));
    
    public Gui03() {
        initComponents();
    }

    private void initComponents() {
        setTitle("Event Programming");
        //setSize(400, 300);        
        setLocationRelativeTo(null);
        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        
        setLayout(new FlowLayout(FlowLayout.LEFT));
        add(bt);
        add(lb);
        pack();
        
        bt.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e){
                clickPerformed(e);
            }
        });
    }
    
    
    private void clickPerformed(ActionEvent e){
        count ++;
        lb.setText(String.format("Number of Clicks: %3d", count));
    }
    
//    private class BtListener implements ActionListener{
//
//        @Override
//        public void actionPerformed(ActionEvent e) {
//            clickPerformed(e);
//        }        
//    }

    public static void main(String[] args) {
        try {
            //UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
            UIManager.setLookAndFeel(new FlatLightLaf());            
        } catch (Exception ex) {
            Logger.getLogger(Gui03.class.getName()).log(Level.SEVERE, null, ex);
        } 
        //Event Dispatching Thread EDT
        EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
                new Gui03().setVisible(true);
            }
        });

    }
}
